class API {
  static const authentication = "https://api.4wrd.tech:8243/token";
  // "https://api.4wrd.tech:8243/authorize/2.0/token?provider=AB4WRD";

  static const dataPost="https://app.securecreditsystems.com/tunl/token";
}
